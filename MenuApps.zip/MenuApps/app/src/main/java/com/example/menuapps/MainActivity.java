package com.example.menuapps;


// MenuItemActivity.java
    public class MenuItemActivity extends AppCompatActivity {
        private EditText dishName, description, price;
        private Spinner courseSpinner;
        private Button saveButton;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.menu_item);

            // Initialize views
            dishName = findViewById(R.id.dish_name);
            description = findViewById(R.id.description);
            price = findViewById(R.id.price);
            courseSpinner = findViewById(R.id.course_spinner);
            saveButton = findViewById(R.id.save_button);

            // Populate course spinner
            String[] courses = getResources().getStringArray(R.array.courses);
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, courses);
            courseSpinner.setAdapter(adapter);

            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Save menu item to ArrayList
                    MenuItem menuItem = new MenuItem(dishName.getText().toString(), description.getText().toString(), courseSpinner.getSelectedItem().toString(), Double.parseDouble(price.getText().toString()));
                    menuItems.add(menuItem);
                    Intent intent = new Intent(MenuItemActivity.this, HomeActivity.class);
                    startActivity(intent);
                }
            });
        }
    }



    // HomeActivity.java
    public class HomeActivity extends AppCompatActivity {
        private ListView menuListView;
        private TextView menuItemCount;
        private Button addMenuItemButton;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.home_screen);

            // Initialize views
            menuListView = findViewById(R.id.menu_list);
            menuItemCount = findViewById(R.id.menu_item_count);
            addMenuItemButton = findViewById(R.id.add_menu_item);

            // Display menu items
            MenuAdapter adapter = new MenuAdapter(this, menuItems);
            menuListView.setAdapter(adapter);
            menuItemCount.setText("Total Menu Items: " + menuItems.size());

            addMenuItemButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(HomeActivity.this, MenuItemActivity.class);
                    startActivity(intent);
                }
            });
        }
    }

}